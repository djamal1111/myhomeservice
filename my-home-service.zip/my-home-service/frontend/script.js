const API_URL = 'http://localhost:3000/api';

// ========== НАВИГАЦИЯ ==========
document.addEventListener('DOMContentLoaded', function() {
    // Навигация
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const section = btn.dataset.section;

            // Обновляем активную кнопку
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Показываем нужную секцию
            document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
            document.getElementById(`${section}-section`).classList.add('active');

            // Загружаем данные
            if (section === 'dashboard') loadDashboard();
            else if (section === 'tasks') loadTasks();
            else if (section === 'purchases') loadPurchases();
            else if (section === 'bills') loadBills();
        });
    });

    // Загружаем дашборд при старте
    loadDashboard();
});

// ========== ОБЩИЕ ФУНКЦИИ ==========
async function fetchData(endpoint) {
    try {
        const response = await fetch(`${API_URL}${endpoint}`);
        if (!response.ok) throw new Error(`HTTP error ${response.status}`);
        return await response.json();
    } catch (error) {
        console.error('Ошибка загрузки данных:', error);
        showMessage('Не удалось загрузить данные', 'error');
        return [];
    }
}

async function postData(endpoint, data) {
    try {
        const response = await fetch(`${API_URL}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        const result = await response.json();
        showMessage(result.message || 'Данные сохранены', 'success');
        return result;
    } catch (error) {
        console.error('Ошибка сохранения:', error);
        showMessage('Ошибка при сохранении данных', 'error');
        return null;
    }
}

function showMessage(text, type = 'info') {
    const messages = {
        success: `✅ ${text}`,
        error: `❌ ${text}`,
        info: `ℹ️ ${text}`
    };
    alert(messages[type]);
}

// ========== ЗАДАЧИ ==========
async function loadTasks() {
    const tasks = await fetchData('/tasks');
    const table = document.getElementById('tasks-table');

    if (!table) return;

    if (tasks.length === 0) {
        table.innerHTML = `<tr><td colspan="5" class="empty-message">Нет задач. Добавьте первую!</td></tr>`;
        return;
    }

    table.innerHTML = '';
    tasks.forEach(task => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><strong>${task.title}</strong></td>
            <td><span class="status-btn pending">${task.category || 'Общее'}</span></td>
            <td>${task.assigned_to || 'Семья'}</td>
            <td>${task.due_date ? new Date(task.due_date).toLocaleDateString('ru-RU') : 'Нет срока'}</td>
            <td>
                <button onclick="toggleTask(${task.id})" class="btn ${task.completed ? 'btn-success' : 'btn-primary'}">
                    ${task.completed ? '✓ Выполнено' : '◯ В работе'}
                </button>
            </td>
        `;
        table.appendChild(row);
    });
}

async function addTask() {
    const title = document.getElementById('task-title').value;
    if (!title) {
        showMessage('Введите название задачи', 'error');
        return;
    }

    await postData('/tasks', {
        title: title,
        category: document.getElementById('task-category').value || 'Общее',
        assigned_to: document.getElementById('task-assigned').value || 'Семья',
        due_date: document.getElementById('task-due').value
    });

    // Очистка полей
    document.getElementById('task-title').value = '';
    document.getElementById('task-category').value = '';
    document.getElementById('task-assigned').value = '';
    document.getElementById('task-due').value = '';

    // Обновление данных
    loadTasks();
    loadDashboard();
}

async function toggleTask(id) {
    try {
        await fetch(`${API_URL}/tasks/${id}/toggle`, { method: 'PUT' });
        showMessage('Статус задачи обновлен', 'success');
        loadTasks();
        loadDashboard();
    } catch (error) {
        showMessage('Ошибка обновления задачи', 'error');
    }
}

// ========== ПОКУПКИ ==========
async function loadPurchases() {
    const purchases = await fetchData('/purchases');
    const container = document.getElementById('purchases-container');

    if (!container) return;

    if (purchases.length === 0) {
        container.innerHTML = '<div class="empty-message">Список покупок пуст. Добавьте первую покупку!</div>';
        return;
    }

    container.innerHTML = '';
    purchases.forEach(purchase => {
        const div = document.createElement('div');
        div.className = 'purchase-item';
        div.innerHTML = `
            <div class="purchase-card ${purchase.bought ? 'bought' : ''}">
                <div class="purchase-info">
                    <h4>${purchase.item}</h4>
                    <div class="purchase-details">
                        <span class="category">${purchase.category || 'Продукты'}</span>
                        <span class="quantity">${purchase.quantity} шт.</span>
                        <span class="date">${new Date(purchase.created_at).toLocaleDateString('ru-RU')}</span>
                    </div>
                </div>
                <div class="purchase-actions">
                    <button onclick="togglePurchase(${purchase.id})" class="btn ${purchase.bought ? 'btn-success' : 'btn-primary'}">
                        ${purchase.bought ? '✓ Куплено' : 'Отметить купленным'}
                    </button>
                    <button onclick="deletePurchase(${purchase.id})" class="btn btn-danger">Удалить</button>
                </div>
            </div>
        `;
        container.appendChild(div);
    });
}

async function addPurchase() {
    const item = document.getElementById('purchase-item').value;
    const category = document.getElementById('purchase-category').value;
    const quantity = document.getElementById('purchase-quantity').value;

    if (!item) {
        showMessage('Введите название товара', 'error');
        return;
    }

    await postData('/purchases', {
        item: item,
        category: category || 'Продукты',
        quantity: parseInt(quantity) || 1
    });

    // Очистка формы
    document.getElementById('purchase-item').value = '';
    document.getElementById('purchase-category').value = '';
    document.getElementById('purchase-quantity').value = '1';

    // Обновление данных
    loadPurchases();
    loadDashboard();
}

async function togglePurchase(id) {
    try {
        await fetch(`${API_URL}/purchases/${id}/toggle`, { method: 'PUT' });
        showMessage('Статус покупки обновлен', 'success');
        loadPurchases();
        loadDashboard();
    } catch (error) {
        showMessage('Ошибка обновления покупки', 'error');
    }
}

async function deletePurchase(id) {
    if (!confirm('Удалить эту покупку из списка?')) return;

    try {
        await fetch(`${API_URL}/purchases/${id}`, { method: 'DELETE' });
        showMessage('Покупка удалена', 'success');
        loadPurchases();
        loadDashboard();
    } catch (error) {
        showMessage('Ошибка удаления покупки', 'error');
    }
}

// ========== СЧЕТА ==========
async function loadBills() {
    const bills = await fetchData('/bills');
    const container = document.getElementById('bills-container');

    if (!container) return;

    if (bills.length === 0) {
        container.innerHTML = '<div class="empty-message">Нет счетов для отображения. Добавьте первый счет!</div>';
        return;
    }

    container.innerHTML = '';
    bills.forEach(bill => {
        const div = document.createElement('div');
        div.className = 'bill-item';
        div.innerHTML = `
            <div class="bill-card ${bill.paid ? 'paid' : 'unpaid'}">
                <div class="bill-header">
                    <h4>${bill.name}</h4>
                    <span class="amount">${bill.amount} руб.</span>
                </div>
                <div class="bill-details">
                    <div class="bill-info">
                        <span>Срок: ${bill.due_date ? new Date(bill.due_date).toLocaleDateString('ru-RU') : 'Не указан'}</span>
                        <span>Добавлен: ${new Date(bill.created_at).toLocaleDateString('ru-RU')}</span>
                    </div>
                    <div class="bill-status ${bill.paid ? 'status-paid' : 'status-pending'}">
                        ${bill.paid ? '✓ Оплачено' : 'Ожидает оплаты'}
                    </div>
                </div>
                <div class="bill-actions">
                    <button onclick="toggleBill(${bill.id})" class="btn ${bill.paid ? 'btn-secondary' : 'btn-success'}">
                        ${bill.paid ? 'Отметить неоплаченным' : 'Отметить оплаченным'}
                    </button>
                    <button onclick="editBill(${bill.id})" class="btn btn-info">Изменить</button>
                </div>
            </div>
        `;
        container.appendChild(div);
    });
}

async function addBill() {
    const name = document.getElementById('bill-name').value;
    const amount = document.getElementById('bill-amount').value;
    const due_date = document.getElementById('bill-due').value;

    if (!name || !amount) {
        showMessage('Заполните название и сумму', 'error');
        return;
    }

    await postData('/bills', {
        name: name,
        amount: parseFloat(amount),
        due_date: due_date || null
    });

    // Очистка формы
    document.getElementById('bill-name').value = '';
    document.getElementById('bill-amount').value = '';
    document.getElementById('bill-due').value = '';

    // Обновление данных
    loadBills();
    loadDashboard();
}

async function toggleBill(id) {
    try {
        await fetch(`${API_URL}/bills/${id}/toggle`, { method: 'PUT' });
        showMessage('Статус счета обновлен', 'success');
        loadBills();
        loadDashboard();
    } catch (error) {
        showMessage('Ошибка обновления счета', 'error');
    }
}

async function editBill(id) {
    const newName = prompt('Введите новое название счета:');
    const newAmount = prompt('Введите новую сумму:');
    const newDueDate = prompt('Введите новый срок (ГГГГ-ММ-ДД или оставьте пустым):');

    if (newName === null && newAmount === null) return;

    try {
        await fetch(`${API_URL}/bills/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: newName || '',
                amount: parseFloat(newAmount) || 0,
                due_date: newDueDate || null
            })
        });
        showMessage('Счет обновлен', 'success');
        loadBills();
    } catch (error) {
        showMessage('Ошибка обновления счета', 'error');
    }
}

// ========== ДАШБОРД ==========
async function loadDashboard() {
    try {
        const [tasks, purchases, bills] = await Promise.all([
            fetchData('/tasks'),
            fetchData('/purchases'),
            fetchData('/bills')
        ]);

        // Активные задачи
        const activeTasks = tasks.filter(t => !t.completed).slice(0, 5);
        const tasksList = document.getElementById('dashboard-tasks');
        if (tasksList) {
            tasksList.innerHTML = '';
            if (activeTasks.length === 0) {
                tasksList.innerHTML = '<li class="empty-message">Все задачи выполнены! 🎉</li>';
            } else {
                activeTasks.forEach(task => {
                    const li = document.createElement('li');
                    li.innerHTML = `
                        <span>${task.title}</span>
                        <small>${task.assigned_to || ''}</small>
                    `;
                    tasksList.appendChild(li);
                });
            }
        }

        // Покупки
        const activePurchases = purchases.filter(p => !p.bought).slice(0, 5);
        const purchasesList = document.getElementById('dashboard-purchases');
        if (purchasesList) {
            purchasesList.innerHTML = '';
            if (activePurchases.length === 0) {
                purchasesList.innerHTML = '<li class="empty-message">Все куплено! 🛍️</li>';
            } else {
                activePurchases.forEach(purchase => {
                    const li = document.createElement('li');
                    li.innerHTML = `
                        <span>${purchase.item}</span>
                        <small>${purchase.quantity} шт.</small>
                    `;
                    purchasesList.appendChild(li);
                });
            }
        }

        // Счета
        const activeBills = bills.filter(b => !b.paid).slice(0, 5);
        const billsList = document.getElementById('dashboard-bills');
        if (billsList) {
            billsList.innerHTML = '';
            if (activeBills.length === 0) {
                billsList.innerHTML = '<li class="empty-message">Все счета оплачены! 💰</li>';
            } else {
                activeBills.forEach(bill => {
                    const li = document.createElement('li');
                    li.innerHTML = `
                        <span>${bill.name}</span>
                        <strong>${bill.amount} руб.</strong>
                    `;
                    billsList.appendChild(li);
                });
            }
        }

        // Статистика
        updateDashboardStats(tasks, purchases, bills);

    } catch (error) {
        console.error('Ошибка загрузки дашборда:', error);
    }
}

function updateDashboardStats(tasks, purchases, bills) {
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.completed).length;
    const activePurchases = purchases.filter(p => !p.bought).length;
    const unpaidBills = bills.filter(b => !b.paid).length;
    const totalAmount = bills.reduce((sum, bill) => sum + bill.amount, 0);

    console.log('📊 Статистика:');
    console.log(`   Задачи: ${completedTasks}/${totalTasks} выполнено`);
    console.log(`   Покупки: ${activePurchases} не куплено`);
    console.log(`   Счета: ${unpaidBills} не оплачено`);
    console.log(`   Общая сумма: ${totalAmount} руб.`);
}