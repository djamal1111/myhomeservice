module.exports = function initDb(db) {
    // Таблица задач
    db.run(`CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        category TEXT,
        assigned_to TEXT,
        due_date DATE,
        completed BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Таблица покупок
    db.run(`CREATE TABLE IF NOT EXISTS purchases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item TEXT NOT NULL,
        category TEXT,
        quantity INTEGER DEFAULT 1,
        bought BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Таблица счетов
    db.run(`CREATE TABLE IF NOT EXISTS bills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        amount REAL NOT NULL,
        due_date DATE,
        paid BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Тестовые данные
    db.get('SELECT COUNT(*) as count FROM tasks', (err, row) => {
        if (row.count === 0) {
            db.run('INSERT INTO tasks (title, category, assigned_to, due_date) VALUES (?, ?, ?, ?)',
                   ['Помыть посуду', 'Уборка', 'Папа', '2024-12-01']);
            db.run('INSERT INTO purchases (item, category) VALUES (?, ?)',
                   ['Хлеб', 'Продукты']);
            db.run('INSERT INTO bills (name, amount) VALUES (?, ?)',
                   ['Интернет', 500]);
        }
    });

    console.log('База данных готова');
};