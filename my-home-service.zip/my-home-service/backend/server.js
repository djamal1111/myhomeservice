const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// Подключение БД
const db = new sqlite3.Database('./database.db', (err) => {
    if (err) console.error('Ошибка БД:', err.message);
    else console.log('База данных подключена');
});

// Инициализация БД
const initDb = require('./init-db');
initDb(db);

// ========== ЗАДАЧИ ==========
app.get('/api/tasks', (req, res) => {
    db.all('SELECT * FROM tasks ORDER BY due_date', [], (err, rows) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json(rows);
    });
});

app.post('/api/tasks', (req, res) => {
    const { title, category, assigned_to, due_date } = req.body;
    db.run('INSERT INTO tasks (title, category, assigned_to, due_date) VALUES (?, ?, ?, ?)',
        [title, category || 'Общее', assigned_to || 'Семья', due_date || null],
        function(err) {
            if (err) res.status(500).json({ error: err.message });
            else res.json({ id: this.lastID, message: 'Задача добавлена' });
        }
    );
});

app.put('/api/tasks/:id/toggle', (req, res) => {
    db.run('UPDATE tasks SET completed = NOT completed WHERE id = ?',
        [req.params.id],
        function(err) {
            if (err) res.status(500).json({ error: err.message });
            else res.json({ message: 'Статус задачи обновлен' });
        }
    );
});

// ========== ПОКУПКИ ==========
app.get('/api/purchases', (req, res) => {
    db.all('SELECT * FROM purchases', [], (err, rows) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json(rows);
    });
});

app.post('/api/purchases', (req, res) => {
    const { item, category, quantity } = req.body;
    db.run('INSERT INTO purchases (item, category, quantity) VALUES (?, ?, ?)',
        [item, category || 'Продукты', quantity || 1],
        function(err) {
            if (err) res.status(500).json({ error: err.message });
            else res.json({ id: this.lastID, message: 'Покупка добавлена' });
        }
    );
});

app.put('/api/purchases/:id/toggle', (req, res) => {
    db.run('UPDATE purchases SET bought = NOT bought WHERE id = ?',
        [req.params.id],
        function(err) {
            if (err) res.status(500).json({ error: err.message });
            else res.json({ message: 'Статус покупки обновлен' });
        }
    );
});

app.delete('/api/purchases/:id', (req, res) => {
    db.run('DELETE FROM purchases WHERE id = ?',
        [req.params.id],
        function(err) {
            if (err) res.status(500).json({ error: err.message });
            else res.json({ message: 'Покупка удалена' });
        }
    );
});

// ========== СЧЕТА ==========
app.get('/api/bills', (req, res) => {
    db.all('SELECT * FROM bills ORDER BY due_date', [], (err, rows) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json(rows);
    });
});

app.post('/api/bills', (req, res) => {
    const { name, amount, due_date } = req.body;
    db.run('INSERT INTO bills (name, amount, due_date) VALUES (?, ?, ?)',
        [name, parseFloat(amount) || 0, due_date || null],
        function(err) {
            if (err) res.status(500).json({ error: err.message });
            else res.json({ id: this.lastID, message: 'Счет добавлен' });
        }
    );
});

app.put('/api/bills/:id/toggle', (req, res) => {
    db.run('UPDATE bills SET paid = NOT paid WHERE id = ?',
        [req.params.id],
        function(err) {
            if (err) res.status(500).json({ error: err.message });
            else res.json({ message: 'Статус счета обновлен' });
        }
    );
});

app.put('/api/bills/:id', (req, res) => {
    const { name, amount, due_date } = req.body;
    db.run('UPDATE bills SET name = ?, amount = ?, due_date = ? WHERE id = ?',
        [name, amount, due_date, req.params.id],
        function(err) {
            if (err) res.status(500).json({ error: err.message });
            else res.json({ message: 'Счет обновлен' });
        }
    );
});

// Главная страница
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(` Сервер запущен: http://localhost:${PORT}`);
    console.log(` База данных: SQLite (database.db)`);
    console.log(` API доступно:`);
    console.log(`   GET  /api/tasks`);
    console.log(`   POST /api/tasks`);
    console.log(`   GET  /api/purchases`);
    console.log(`   POST /api/purchases`);
    console.log(`   GET  /api/bills`);
    console.log(`   POST /api/bills`);
});